## Packages
framer-motion | Essential for smooth page transitions and micro-interactions in a premium UI

## Notes
Dynamic images should be placed in `client/public/images/`.
The app uses a strict minimalist aesthetic with a focus on typography and whitespace.
